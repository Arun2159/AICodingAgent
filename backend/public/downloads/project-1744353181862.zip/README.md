```markdown
# CRUD Application

This is a simple CRUD application built using Node.js/Express for the backend and Bootstrap 5 for the frontend.

## Features