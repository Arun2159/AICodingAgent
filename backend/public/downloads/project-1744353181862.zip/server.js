```javascript
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
app.use(express.static('public'));
app.use(bodyParser.json());

const dataFilePath = path.join(__dirname, 'data', 'crud_data.json');

function readData() {
    const data = fs.readFileSync(dataFilePath, { encoding: 'utf8', flag: 'r' });
    return JSON.parse(data || '[]');
}

function writeData(data) {
    fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
}

app.get('/api/users', (req, res) => {
    res.json(readData());
});

app.post('/api/users', (req, res) => {
    const users = readData();
    const newUser = { id: Date.now().toString(), ...req.body };
    users.push(newUser);
    writeData(users);
    res.status(201).json(newUser);
});

app.get('/api/users/:id', (req, res) => {
    const users = readData();
    const user = users.find(u => u.id === req.params.id);
    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ error: 'User not found' });
    }
});

app.put('/api/users/:id', (req, res) => {
    const users = readData();
    const index = users.findIndex(u => u.id === req.params.id);
    if (index !== -1) {
        users[index] = { ...users[index], ...req.body };
        writeData(users);
        res.json(users[index]);
    } else {
        res.status(404).json({ error: 'User not found' });
    }
});

app.delete('/api/users/:id', (req, res) => {
    const users = readData();
    const newUsers = users.filter(u => u.id !== req.params.id);
    writeData(newUsers);
    res.status(204).send();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
```

###