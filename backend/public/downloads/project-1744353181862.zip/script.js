```javascript
$(document).ready(function() {
    const form = $('#crud-form');
    const nameInput = $('#name');
    const emailInput = $('#email');
    const userIdInput = $('#user-id');
    const dataTable = $('#data-table');
    const loading = $('#loading');

    function fetchData() {
        loading.show();
        $.get('/api/users', function(users) {
            loading.hide();
            dataTable.empty();
            users.forEach((user, index) => {
                dataTable.append(`
                    <tr>
                        <th scope="row">${index + 1}</th>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-warning btn-sm edit-btn" data-id="${user.id}"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger btn-sm delete-btn" data-id="${user.id}"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                `);
            });
        }).fail(function(error) {
            console.error('Error fetching data', error);
            loading.hide();
        });
    }

    form.on('submit', function(e) {
        e.preventDefault();
        const name = nameInput.val();
        const email = emailInput.val();
        const userId = userIdInput.val();

        if (userId) {
            $.ajax({
                url: `/api/users/${userId}`,
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({ name, email }),
                success: function() {
                    fetchData();
                    form[0].reset();
                    userIdInput.val('');
                },
                error: function(error) {
                    console.error('Error updating user', error);
                }
            });
        } else {
            $.post('/api/users', { name, email }, function() {
                fetchData();
                form[0].reset();
            }).fail(function(error) {
                console.error('Error creating user', error);
            });
        }
    });

    dataTable.on('click', '.edit-btn', function() {
        const id = $(this).data('id');
        $.get(`/api/users/${id}`, function(user) {
            nameInput.val(user.name);
            emailInput.val(user.email);
            userIdInput.val(user.id);
        }).fail(function(error) {
            console.error('Error fetching user for edit', error);
        });
    });

    dataTable.on('click', '.delete-btn', function() {
        const id = $(this).data('id');
        $.ajax({
            url: `/api/users/${id}`,
            type: 'DELETE',
            success: function() {
                fetchData();
            },
            error: function(error) {
                console.error('Error deleting user', error);
            }
        });
    });

    fetchData();
});
```

###