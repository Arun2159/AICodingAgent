```javascript
$(document).ready(function () {
    function fetchData() {
        $('#loading').removeClass('d-none');
        $.get('/api/data', function (data) {
            $('#loading').addClass('d-none');
            $('#data-table').empty();
            data.forEach(user => {
                $('#data-table').append(`
                    <tr>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-sm btn-warning edit-btn" data-id="${user.id}"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-danger delete-btn" data-id="${user.id}"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                `);
            });
        });
    }

    fetchData();

    $('#crud-form').submit(function (e) {
        e.preventDefault();
        
        const name = $('#name').val().trim();
        const email = $('#email').val().trim();

        if (!name || !email) {
            $('#name').toggleClass('is-invalid', !name);
            $('#email').toggleClass('is-invalid', !email);
            return;
        }

        $('#submit-btn').prop('disabled', true).text('Submitting...');
        
        $.ajax({
            url: '/api/data',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ name, email }),
            success: function () {
                fetchData();
                $('#crud-form')[0].reset();
                $('#submit-btn').prop('disabled', false).text('Submit');
            },
            error: function () {
                alert('Error saving data.');
                $('#submit-btn').prop('disabled', false).text('Submit');
            }
        });
    });
    
    $(document).on('click', '.delete-btn', function () {
        const id = $(this).data('id');
        $.ajax({
            url: `/api/data/${id}`,
            method: 'DELETE',
            success: fetchData,
            error: function () {
                alert('Error deleting data.');
            }
        });
    });

    $(document).on('click', '.edit-btn', function () {
        const id = $(this).data('id');
        $.get(`/api/data/${id}`, function (user) {
            $('#name').val(user.name);
            $('#email').val(user.email);
            $('#submit-btn').text('Update').off('click').on('click', function (e) {
                e.preventDefault();
                $.ajax({
                    url: `/api/data/${id}`,
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        name: $('#name').val(),
                        email: $('#email').val()
                    }),
                    success: function () {
                        $('#submit-btn').text('Submit');
                        fetchData();
                        $('#crud-form')[0].reset();
                    },
                    error: function () {
                        alert('Error updating data.');
                    }
                });
            });
        });
    });
});
```

###