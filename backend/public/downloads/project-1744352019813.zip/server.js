```javascript
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const dataFile = path.join(__dirname, 'data', 'crud_data.json');

function readData() {
    return JSON.parse(fs.readFileSync(dataFile, 'utf8'));
}

function writeData(data) {
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

app.get('/api/data', (req, res) => {
    res.json(readData());
});

app.post('/api/data', (req, res) => {
    const data = readData();
    const newItem = { id: Date.now().toString(), ...req.body };
    data.push(newItem);
    writeData(data);
    res.status(201).json(newItem);
});

app.put('/api/data/:id', (req, res) => {
    const data = readData();
    const index = data.findIndex(item => item.id === req.params.id);
    if (index === -1) return res.status(404).send('Item not found');
    data[index] = { id: req.params.id, ...req.body };
    writeData(data);
    res.json(data[index]);
});

app.delete('/api/data/:id', (req, res) => {
    const data = readData();
    const newData = data.filter(item => item.id !== req.params.id);
    writeData(newData);
    res.status(204).send();
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
```

###