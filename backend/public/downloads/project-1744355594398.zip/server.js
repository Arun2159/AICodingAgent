```js
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'crud_data.json');

app.use(bodyParser.json());
app.use(express.static('public'));

const readData = () => {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
};

const writeData = (data) => {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};

app.get('/api/users', (req, res) => {
    res.json(readData());
});

app.get('/api/users/:id', (req, res) => {
    const users = readData();
    const user = users.find(u => u.id === parseInt(req.params.id));
    if (user) {
        res.json(user);
    } else {
        res.status(404).send('User not found');
    }
});

app.post('/api/users', (req, res) => {
    const users = readData();
    const user = { id: Date.now(), ...req.body };
    users.push(user);
    writeData(users);
    res.status(201).send('User added');
});

app.put('/api/users/:id', (req, res) => {
    const users = readData();
    const index = users.findIndex(u => u.id === parseInt(req.params.id));
    if (index !== -1) {
        users[index] = { id: users[index].id, ...req.body };
        writeData(users);
        res.send('User updated');
    } else {
        res.status(404).send('User not found');
    }
});

app.delete('/api/users/:id', (req, res) => {
    const users = readData();
    const newUsers = users.filter(u => u.id !== parseInt(req.params.id));
    if (users.length !== newUsers.length) {
        writeData(newUsers);
        res.send('User deleted');
    } else {
        res.status(404).send('User not found');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
```

###