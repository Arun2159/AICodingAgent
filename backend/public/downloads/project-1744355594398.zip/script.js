```js
$(document).ready(function () {
    const apiUrl = "http://localhost:3000/api/users";
    let updateId = null;

    const createAlert = (message, type) => {
        return `<div class="alert alert-${type} alert-dismissible" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>`;
    };

    const loadUsers = () => {
        $.get(apiUrl, function (users) {
            $('#dataDisplaySection').empty();
            users.forEach(user => {
                $('#dataDisplaySection').append(`
                    <tr>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-warning btn-sm edit" data-id="${user.id}"><i class="fas fa-edit"></i> Edit</button>
                            <button class="btn btn-danger btn-sm delete" data-id="${user.id}"><i class="fas fa-trash-alt"></i> Delete</button>
                        </td>
                    </tr>
                `);
            });
        }).fail(() => {
            $('#alertPlaceholder').html(createAlert('Failed to load data. Please try again later.', 'danger'));
        });
    };

    $('#crudForm').on('submit', function (e) {
        e.preventDefault();
        const name = $('#name').val();
        const email = $('#email').val();

        if (updateId === null) {
            $.post(apiUrl, { name, email })
                .done(() => {
                    $('#alertPlaceholder').html(createAlert('User created successfully!', 'success'));
                    loadUsers();
                })
                .fail(() => {
                    $('#alertPlaceholder').html(createAlert('Failed to create user. Please try again.', 'danger'));
                });
        } else {
            $.ajax({
                url: `${apiUrl}/${updateId}`,
                method: 'PUT',
                data: { name, email }
            }).done(() => {
                $('#alertPlaceholder').html(createAlert('User updated successfully!', 'success'));
                loadUsers();
                $('#updateButton').hide();
                $('#crudForm')[0].reset();
                updateId = null;
            }).fail(() => {
                $('#alertPlaceholder').html(createAlert('Failed to update user. Please try again.', 'danger'));
            });
        }
    });

    $(document).on('click', '.edit', function () {
        const id = $(this).data('id');
        $.get(`${apiUrl}/${id}`, function (user) {
            $('#name').val(user.name);
            $('#email').val(user.email);
            $('#updateButton').show();
            updateId = id;
        }).fail(() => {
            $('#alertPlaceholder').html(createAlert('Failed to fetch user data.', 'danger'));
        });
    });

    $(document).on('click', '.delete', function () {
        const id = $(this).data('id');
        if (confirm('Are you sure you want to delete this user?')) {
            $.ajax({
                url: `${apiUrl}/${id}`,
                method: 'DELETE'
            }).done(() => {
                $('#alertPlaceholder').html(createAlert('User deleted successfully!', 'success'));
                loadUsers();
            }).fail(() => {
                $('#alertPlaceholder').html(createAlert('Failed to delete user.', 'danger'));
            });
        }
    });

    loadUsers();
});
```

###