```javascript
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/crud_app', { useNewUrlParser: true, useUnifiedTopology: true });

const itemSchema = new mongoose.Schema({
    name: String,
    email: String
});

const Item = mongoose.model('Item', itemSchema);

// CRUD operations
app.post('/api/items', (req, res) => {
    const newItem = new Item(req.body);
    newItem.save((err) => {
        if (err) return res.status(500).send(err.message);
        res.status(201).json(newItem);
    });
});

app.get('/api/items', (req, res) => {
    Item.find({}, (err, items) => {
        if (err) return res.status(500).send(err.message);
        res.json(items);
    });
});

app.get('/api/items/:id', (req, res) => {
    Item.findById(req.params.id, (err, item) => {
        if (err) return res.status(500).send(err.message);
        if (!item) return res.status(404).send('Item not found');
        res.json(item);
    });
});

app.put('/api/items/:id', (req, res) => {
    Item.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, item) => {
        if (err) return res.status(500).send(err.message);
        res.json(item);
    });
});

app.delete('/api/items/:id', (req, res) => {
    Item.findByIdAndRemove(req.params.id, (err) => {
        if (err) return res.status(500).send(err.message);
        res.send('Item deleted');
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
```

###