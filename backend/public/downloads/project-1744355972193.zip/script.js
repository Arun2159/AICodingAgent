```javascript
$(document).ready(function () {
    const apiUrl = '/api/items';

    const loadData = () => {
        $.get(apiUrl, (data) => {
            let rows = '';
            data.forEach(item => {
                rows += `<tr>
                    <td>${item.name}</td>
                    <td>${item.email}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editItem('${item._id}')">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteItem('${item._id}')">Delete</button>
                    </td>
                </tr>`;
            });
            $('#dataDisplay').html(rows);
        });
    };

    const displayMessage = (message, type = 'success') => {
        const feedback = $('#formFeedback');
        feedback.removeClass().addClass(`alert alert-${type}`).text(message).fadeIn(500).delay(3000).fadeOut(500);
    };

    $('#crudForm').submit(function (e) {
        e.preventDefault();
        const id = $('#crudForm').data('id');
        const name = $('#name').val().trim();
        const email = $('#email').val().trim();

        if (id) {
            // Update Operation
            $.ajax({
                url: `${apiUrl}/${id}`,
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({ name, email }),
                success: function () {
                    displayMessage('Updated successfully!');
                    $('#crudForm')[0].reset();
                    $('#crudForm').removeData('id');
                    $('button[type="submit"]').text('Submit');
                    loadData();
                },
                error: function (jqXHR) {
                    displayMessage(jqXHR.responseText, 'danger');
                }
            });
        } else {
            // Create Operation
            $.post(apiUrl, { name, email }, (response) => {
                displayMessage('Added successfully!');
                $('#crudForm')[0].reset();
                loadData();
            }).fail(function (jqXHR) {
                displayMessage(jqXHR.responseText, 'danger');
            });
        }
    });

    window.editItem = function (id) {
        $.get(`${apiUrl}/${id}`, (data) => {
            $('#name').val(data.name);
            $('#email').val(data.email);
            $('#crudForm').data('id', id);
            $('button[type="submit"]').text('Update');
        });
    };

    window.deleteItem = function (id) {
        $.ajax({
            url: `${apiUrl}/${id}`,
            type: 'DELETE',
            success: function () {
                displayMessage('Deleted successfully!');
                loadData();
            },
            error: function (jqXHR) {
                displayMessage(jqXHR.responseText, 'danger');
            }
        });
    };

    loadData();
});
```

###