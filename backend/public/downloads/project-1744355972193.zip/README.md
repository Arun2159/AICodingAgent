```markdown
# CRUD Application

This is a simple CRUD (Create, Read, Update, Delete) application built using Node.js, Express, MongoDB, and a Bootstrap frontend.

## Prerequisites

- Node.js installed on your machine
- MongoDB installed and running

## Setup Instructions

1. Clone the repository or download the source code.

2. Navigate into the project directory.

3. Install the dependencies:
   ```bash
   npm install
   ```

4. Start the MongoDB server on your local machine:
   ```bash
   mongod
   ```

5. Start the application:
   ```bash
   node server.js
   ```

6. Open your web browser and visit:
   ```
   http://localhost:3000
   ```

Feel free to fork or contribute to the project!
```

### File structure:

``