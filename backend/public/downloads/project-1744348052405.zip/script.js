```javascript
$(document).ready(function(){
  // code here
});
```