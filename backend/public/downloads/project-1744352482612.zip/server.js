```js
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const filePath = path.join(__dirname, 'data', 'crud_data.json');

// Utility to read JSON data from file
function readData() {
    return JSON.parse(fs.readFileSync(filePath));
}

// Utility to write JSON data to file
function writeData(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

app.get('/api/users', (req, res) => {
    const users = readData();
    res.json(users);
});

app.post('/api/users', (req, res) => {
    const users = readData();
    const newUser = {
        id: users.length ? users[users.length - 1].id + 1 : 1,
        name: req.body.name,
        email: req.body.email
    };
    users.push(newUser);
    writeData(users);
    res.status(201).json(newUser);
});

app.get('/api/users/:id', (req, res) => {
    const users = readData();
    const user = users.find(u => u.id == req.params.id);
    if (!user) return res.status(404).send('User not found');
    res.json(user);
});

app.put('/api/users/:id', (req, res) => {
    const users = readData();
    const userIndex = users.findIndex(u => u.id == req.params.id);
    if (userIndex === -1) return res.status(404).send('User not found');

    const updatedUser = {
        ...users[userIndex],
        name: req.body.name,
        email: req.body.email
    };

    users[userIndex] = updatedUser;
    writeData(users);
    res.json(updatedUser);
});

app.delete('/api/users/:id', (req, res) => {
    const users = readData();
    const userIndex = users.findIndex(u => u.id == req.params.id);
    if (userIndex === -1) return res.status(404).send('User not found');

    users.splice(userIndex, 1);
    writeData(users);