```js
$(document).ready(function() {
    const form = $('#userForm');
    const notification = $('#notification');
    const loading = $('#loading');
    const userTableBody = $('#userTableBody');

    function showNotification(message, type = 'success') {
        notification.removeClass('d-none alert-success alert-danger').addClass(`alert-${type}`).text(message).fadeIn();
        setTimeout(() => notification.fadeOut(), 3000);
    }

    function toggleLoading(show = true) {
        if (show) {
            loading.removeClass('d-none');
        } else {
            loading.addClass('d-none');
        }
    }

    function clearForm() {
        $('#name').val('');
        $('#email').val('');
        $('#userId').val('');
        form.removeClass('was-validated');
    }

    function fetchUsers() {
        toggleLoading(true);
        $.get('/api/users', function(data) {
            toggleLoading(false);
            userTableBody.empty();
            data.forEach(user => {
                const row = `<tr>
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>
                        <button class="btn btn-warning btn-sm mx-1 edit" data-id="${user.id}">Edit</button>
                        <button class="btn btn-danger btn-sm mx-1 delete" data-id="${user.id}">Delete</button>
                    </td>
                </tr>`;
                userTableBody.append(row);
            });
            attachEventHandlers();
        });
    }

    function attachEventHandlers() {
        $('.edit').click(function() {
            const id = $(this).data('id');
            $.get(`/api/users/${id}`, function(user) {
                $('#name').val(user.name);
                $('#email').val(user.email);
                $('#userId').val(user.id);
            });
        });

        $('.delete').click(function() {
            const id = $(this).data('id');
            $.ajax({
                url: `/api/users/${id}`,
                type: 'DELETE',
                success: function() {
                    showNotification('User deleted successfully.');
                    fetchUsers();
                },
                error: function() {
                    showNotification('Error deleting user.', 'danger');
                }
            });
        });
    }

    form.on('submit', function(event) {
        event.preventDefault();
        if (!this.checkValidity()) {
            event.stopPropagation();
            form.addClass('was-validated');
            return;
        }

        const userId = $('#userId').val();
        const userData = {
            name: $('#name').val(),
            email: $('#email').val()
        };

        const requestType = userId ? 'PUT' : 'POST';
        const url = userId ? `/api/users/${userId}` : '/api/users';
        
        toggleLoading(true);
        $.ajax({
            url: url,
            type: requestType,
            data: JSON.stringify(userData),
            contentType: 'application/json',
            success: function() {
                clearForm();
                toggleLoading(false);
                showNotification(`User ${requestType === 'POST' ? 'created' : 'updated'} successfully.`);
                fetchUsers();
            },
            error: function() {
                toggleLoading(false);
                showNotification(`Error ${requestType === 'POST' ? 'creating' : 'updating'} user.`, 'danger');
            }
        });
    });

    fetchUsers();
});
```

###