```javascript
$(document).ready(function() {
    const form = $('#crudForm');
    const dataTable = $('#dataTable');
    const submitButton = $('#submitButton');
    const updateButton = $('#updateButton');
    let editingUserId = null;

    function loadData() {
        $.ajax({
            url: '/api/users',
            method: 'GET',
            success: function(data) {
                dataTable.html('');
                data.forEach(user => {
                    dataTable.append(`
                        <tr>
                            <td>${user.name}</td>
                            <td>${user.email}</td>
                            <td>
                                <button class="btn btn-sm btn-info" onclick="editUser('${user.id}', '${user.name}', '${user.email}')">Edit</button>
                                <button class="btn btn-sm btn-danger" onclick="deleteUser('${user.id}')">Delete</button>
                            </td>
                        </tr>
                    `);
                });
            }
        });
    }
    
    form.on('submit', function(e) {
        e.preventDefault();
        const name = $('#name').val();
        const email = $('#email').val();
        
        if (editingUserId) {
            $.ajax({
                url: `/api/users/${editingUserId}`,
                method: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({ name, email }),
                success: function() {
                    loadData();
                    editingUserId = null;
                    form.trigger("reset");
                    submitButton.show();
                    updateButton.hide();
                }
            });
        } else {
            $.ajax({
                url: '/api/users',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ name, email }),
                success: function() {
                    loadData();
                    form.trigger("reset");
                }
            });
        }
    });

    window.editUser = function(id, name, email) {
        editingUserId = id;
        $('#name').val(name);
        $('#email').val(email);
        submitButton.hide();
        updateButton.show();
    };

    window.deleteUser = function(id) {
        $.ajax({
            url: `/api/users/${id}`,
            method: 'DELETE',
            success: function() {
                loadData();
            }
        });
    };

    loadData();
});
```

###