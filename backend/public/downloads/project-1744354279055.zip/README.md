```markdown
# CRUD Application

This CRUD application allows you to manage users with the ability to Create, Read, Update, and Delete users using a modern web interface and a Node.js backend.

## Setup Instructions

1. **Clone the repository.**
   
2. **Install dependencies:**

   ```
   npm install
   ```

3. **Start the server:**

   ```
   node server.js
   ```

4. **Access the application in your web browser:**

   Open your