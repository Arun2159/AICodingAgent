```javascript
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const dataFilePath = path.join(__dirname, 'data', 'crud_data.json');

app.use(express.static('public'));
app.use(bodyParser.json());

app.get('/api/users', (req, res) => {
    fs.readFile(dataFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Server Error' });
        }
        res.json(JSON.parse(data));
    });
});

app.post('/api/users', (req, res) => {
    const newUser = { id: String(Date.now()), ...req.body };

    fs.readFile(dataFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Server Error' });
        }
        const users = JSON.parse(data);
        users.push(newUser);
        fs.writeFile(dataFilePath, JSON.stringify(users, null, 2), (writeErr) => {
            if (writeErr) {
                return res.status(500).json({ message: 'Server Error' });
            }
            res.status(201).json(newUser);
        });
    });
});

app.put('/api/users/:id', (req, res) => {
    const userId = req.params.id;
    
    fs.readFile(dataFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Server Error' });
        }
        let users = JSON.parse(data);
        users = users.map(user => user.id === userId ? { ...user, ...req.body } : user);
        fs.writeFile(dataFilePath, JSON.stringify(users, null, 2), (writeErr) => {
            if (writeErr) {
                return res.status(500).json({ message: 'Server Error' });
            }
            res.status(200).json({ message: 'User updated' });
        });
    });
});

app.delete('/api/users/:id', (req, res) => {
    const userId = req.params.id;

    fs.readFile(dataFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Server Error' });
        }
        let users = JSON.parse(data);
        users = users.filter(user => user.id !== userId);
        fs.writeFile(dataFilePath, JSON.stringify(users, null, 2), (writeErr) => {
            if (writeErr) {
                return res.status(500).json({ message: 'Server Error' });
            }
            res.status(200).json({ message: 'User deleted' });
        });
    });
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
```

###