```javascript
document.querySelector("#visaForm").addEventListener("submit", function (e) {
    e.preventDefault();

    var isValid = true;

    document.querySelectorAll("input, select").forEach(function (input) {
        if (!input.checkValidity()) {
            isValid = false;
        }
    });

    if (isValid) {
        alert("Form submitted successfully");
    } else {
        alert("Please correct the errors in the form");
    }
});
```