```javascript
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use(express.json());

const dataFilePath = path.join(__dirname, 'data', 'crud_data.json');

// Utility function to read data from the JSON file
function readData() {
    const data = fs.readFileSync(dataFilePath);
    return JSON.parse(data);
}

// Utility function to write data to the JSON file
function writeData(data) {
    fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
}

// Get all users
app.get('/api/users', (req, res) => {
    const users = readData();
    res.json(users);
});

// Get a single user by ID
app.get('/api/users/:id', (req, res) => {
    const users = readData();
    const user = users.find(u => u.id === parseInt(req.params.id));
    if (user) {
        res.json(user);
    } else {
        res.status(404).send({message: 'User not found'});
    }
});

// Create a new user
app.post('/api/users', (req, res) => {
    const users = readData();
    const newUser = {
        id: Date.now(),
        ...req.body
    };
    users.push(newUser);
    writeData(users);
    res.status(201).json(newUser);
});

// Update an existing user
app.put('/api/users/:id', (req, res) => {
    const users = readData();
    const userIndex = users.findIndex(u => u.id === parseInt(req.params.id));
    if (userIndex >= 0) {
        users[userIndex] = { id: users[userIndex].id, ...req.body };
        writeData(users);
        res.json(users[userIndex]);
    } else {
        res.status(404).send({message: 'User not found'});
    }
});

// Delete a user
app.delete('/api/users/:id', (req, res) => {
    let users = readData();
    users = users.filter(u => u.id !== parseInt(req.params.id));