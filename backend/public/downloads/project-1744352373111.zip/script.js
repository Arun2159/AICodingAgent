```js
$(document).ready(function () {
    const $form = $('#userForm');
    const $name = $('#name');
    const $email = $('#email');
    const $userId = $('#userId');

    function showMessage(message, type = 'success') {
        const alertHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>`;
        $('#alertPlaceholder').html(alertHTML);
    }

    function fetchUsers() {
        $.get('/api/users', function (data) {
            const rows = data.map(user => `
                <tr>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>
                        <button class="btn btn-warning btn-sm edit-btn" data-id="${user.id}">Edit</button>
                        <button class="btn btn-danger btn-sm delete-btn" data-id="${user.id}">Delete</button>
                    </td>
                </tr>
            `);
            $('#userTable').html(rows.join(''));
        });
    }

    $form.on('submit', function (e) {
        e.preventDefault();
        const user = {
            name: $name.val().trim(),
            email: $email.val().trim(),
        };
        if (!$form[0].checkValidity()) {
            $form[0].classList.add('was-validated');
            return;
        }
        const id = $userId.val();
        if (id) {
            $.ajax({
                url: `/api/users/${id}`,
                method: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify(user),
                success: () => {
                    showMessage('User updated successfully.');
                    fetchUsers();
                    $form[0].reset();
                    $userId.val('');
                },
                error: () => showMessage('Error updating user.', 'danger')
            });
        } else {
            $.post('/api/users', user, () => {
                showMessage('User added successfully.');
                fetchUsers();
                $form[0].reset();
            }).fail(() => showMessage('Error adding user.', 'danger'));
        }
    });

    $('#userTable').on('click', '.edit-btn', function () {
        const id = $(this).data('id');
        $.get(`/api/users/${id}`, user => {
            $name.val(user.name);
            $email.val(user.email);
            $userId.val(user.id);
        });
    });

    $('#userTable').on('click', '.delete-btn', function () {
        const id = $(this).data('id');
        if (confirm('Are you sure you want to delete this user?')) {
            $.ajax({
                url: `/api/users/${id}`,
                method: 'DELETE',
                success: () => {
                    showMessage('User deleted successfully.');
                    fetchUsers();
                },
                error: () => showMessage('Error deleting user.', 'danger')
            });
        }
    });

    // Initial data fetch
    fetchUsers();
});
```

####