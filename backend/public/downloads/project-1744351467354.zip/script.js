```javascript
$(document).ready(function() {
	// Prevent form submission
	$('#visaForm').on('submit', function(e) {
		e.preventDefault();
		// Validate form
		if(!this.checkValidity()) {
			// If form is invalid, get the first invalid element
			var invalids = $(this).find(':invalid');
			var firstInvalid = invalids[0];

			// If first invalid element is in a collapsed section, expand that section
			if ($(firstInvalid).is(':hidden')) {
				$(firstInvalid).collapse('show');
			}

			// And scroll to the invalid element
			firstInvalid.scrollIntoView({behavior: "smooth"});
		} else {
			// If form is valid, show a success message
			alert('Form submitted successfully!');
		}
	});
});
```